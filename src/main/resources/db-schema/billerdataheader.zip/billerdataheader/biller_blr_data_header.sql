-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: biller
-- ------------------------------------------------------
-- Server version	8.0.1-dmr-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blr_data_header`
--

DROP TABLE IF EXISTS `blr_data_header`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blr_data_header` (
  `header_id` smallint(5) DEFAULT NULL,
  `header_desc` varchar(100) NOT NULL,
  `ilc_order` smallint(5) DEFAULT NULL,
  `sla_order` smallint(5) DEFAULT NULL,
  `field_name` varchar(50) DEFAULT NULL,
  `bulk_update` varchar(50) DEFAULT NULL,
  `customize_columns` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blr_data_header`
--

LOCK TABLES `blr_data_header` WRITE;
/*!40000 ALTER TABLE `blr_data_header` DISABLE KEYS */;
INSERT INTO `blr_data_header` VALUES (1,'Select',1,1,NULL,NULL,NULL),(2,'Emp ID',2,7,'emp_id',NULL,NULL),(3,'Name',3,8,'emp_name',NULL,NULL),(4,'Claim Code',4,10,'claim_code',NULL,NULL),(5,'Activity',5,9,'activity',NULL,NULL),(6,'Week End',6,2,'weekend_date',NULL,NULL),(7,'Total Hrs',7,12,'total_hours',NULL,NULL),(8,'Shift',8,13,'shift_type',NULL,NULL),(9,'US/INDIA',9,0,'us_ind',NULL,NULL),(10,'Location',10,11,'',NULL,NULL),(11,'Billing',11,15,'billing_type',NULL,NULL),(12,'Category',12,14,'category',NULL,NULL),(13,'BAM',13,20,'bam',NULL,NULL),(14,'App Aea',14,17,'app_area',NULL,NULL),(15,'Business Area',15,18,'business_area',NULL,NULL),(16,'Month',16,0,'month',NULL,NULL),(17,'Quarter',17,0,'quarter',NULL,NULL),(18,'DM',18,16,'dm','1',NULL),(19,'ASM',19,3,'asm','1',NULL),(20,'ASD',20,4,'asd',NULL,NULL),(21,'WR #',21,24,'work_type',NULL,NULL),(22,'Is Ticket ?',22,0,'is_ticket',NULL,NULL),(23,'Resource Type',23,0,'staff_type',NULL,NULL),(24,'CTC WR',24,0,'is_ctc',NULL,NULL),(25,'RTC WR',25,0,'is_rtc',NULL,NULL),(26,'Planned Hours',26,25,'planned_hours',NULL,NULL),(27,'Billable?',27,22,'is_billable','1',NULL),(28,'Remarks',28,21,'remarks','1',NULL),(29,'CTC/RTC',29,29,'ctc_or_rtc',NULL,NULL),(30,'Work Type',30,0,'work_type',NULL,NULL),(31,'WR Description',31,27,'wr_desc',NULL,NULL),(32,'Cost Center',32,28,'cost_center',NULL,NULL),(33,'Category 2',33,0,'category2',NULL,NULL),(34,'OnOffLanded',34,0,'on_off_landed',NULL,NULL),(35,'Tower',35,19,'tower',NULL,NULL),(36,'Last Modified',36,0,'last_modified',NULL,NULL),(37,'ASM (ITWR)',37,5,'asm_itwr',NULL,NULL),(38,'ASD (ITWR)',38,6,'asd_itwr',NULL,NULL),(39,'ITWR Actuals',39,0,NULL,NULL,NULL),(40,'Group',40,0,'group_type',NULL,NULL),(41,'Vendor Class',41,30,'vendor_class',NULL,NULL),(42,'WR/INC/DEF',42,0,NULL,NULL,NULL),(43,'Action',0,0,NULL,NULL,NULL),(44,'Comments',0,26,NULL,NULL,NULL),(45,'Modified By',0,31,NULL,NULL,NULL),(46,'Account ID',43,32,NULL,NULL,NULL);
/*!40000 ALTER TABLE `blr_data_header` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-07 12:46:56
